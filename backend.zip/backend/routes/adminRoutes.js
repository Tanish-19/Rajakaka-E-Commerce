import express from 'express';
import { login, addProduct, getProducts, updateProduct, deleteProduct } from '../controllers/adminController.js';
import { protectAdmin } from '../middleware/authMiddleware.js'; // Named import

const router = express.Router();

// Admin login (public)
router.post('/login', login);

// Protected admin routes
router.post('/products', protectAdmin, addProduct);
router.get('/products', protectAdmin, getProducts);
router.put('/products/:id', protectAdmin, updateProduct);
router.delete('/products/:id', protectAdmin, deleteProduct);

export default router;
